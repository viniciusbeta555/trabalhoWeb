<!DOCTYPE html>
<html lang="pt-br">
<head>
	<meta charset="utf-8">
	<title> Pesquisar no Banco de dados </title>
	<link rel="stylesheet" type="text/css" href="css/estilo.css">
</head>
<body>
	<main>
		<header> Pesquise por um nome! </header>
	<form action="readInfo.php" method="post">
		<p> <input type="text" name="nome"> </p>
		<button type="submit"> Pesquisar </button>
	</form>
    </main>
</body>
</html>
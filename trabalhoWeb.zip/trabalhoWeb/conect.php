<?php

$conect = new PDO("mysql:dbname=trabalho_web; host=localhost; charset=utf8", "root", "");